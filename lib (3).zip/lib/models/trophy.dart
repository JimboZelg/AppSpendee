class Trophy {
  final String title;
  final bool unlocked;

  Trophy({required this.title, required this.unlocked});
}
