import 'package:flutter/material.dart';
import 'package:spendee/screens/learning/learning_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inicio'),
      ),
      drawer: _CustomDrawer(),
      body: const Center(
        child: Text(
          'Bienvenido a tu app de Finanzas',
          style: TextStyle(fontSize: 24),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class _CustomDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            _DrawerHeader(),
            const SizedBox(height: 10),
            _DrawerItem(
              icon: Icons.home,
              title: 'Inicio',
              onTap: () {
                Navigator.pop(context);
              },
            ),
            _DrawerItem(
              icon: Icons.history,
              title: 'Historial',
              onTap: () {
                Navigator.pop(context);
              },
            ),
            _DrawerItem(
              icon: Icons.school,
              title: 'Aprendizaje',
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => LearningScreen()),
                );
              },
            ),
            _DrawerItem(
              icon: Icons.settings,
              title: 'Configuración',
              onTap: () {
                Navigator.pop(context);
              },
            ),
            const Spacer(),
            const Padding(
              padding: EdgeInsets.all(12.0),
              child: Text(
                'Versión 1.0.0',
                style: TextStyle(color: Colors.grey),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class _DrawerHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return UserAccountsDrawerHeader(
      accountName: const Text('Usuario'),
      accountEmail: const Text('usuario@email.com'),
      currentAccountPicture: CircleAvatar(
        backgroundColor: Colors.white,
        child: const Icon(
          Icons.person,
          size: 40,
          color: Colors.blueGrey,
        ),
      ),
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor,
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _DrawerItem({
    Key? key,
    required this.icon,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: Colors.blueAccent),
      title: Text(
        title,
        style: const TextStyle(fontSize: 18),
      ),
      hoverColor: Colors.blue[50],
      onTap: onTap,
    );
  }
}
