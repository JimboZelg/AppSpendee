import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:spendee/providers/learning_provider.dart';

class LevelDetailScreen extends StatelessWidget {
  final int levelId;

  const LevelDetailScreen({Key? key, required this.levelId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Nivel ${levelId + 1}'),
      ),
      body: Center(
        child: ElevatedButton(
          child: const Text('Completar Nivel'),
          onPressed: () {
            Provider.of<LearningProvider>(context, listen: false).completeLevel(levelId);
            Navigator.pop(context);
          },
        ),
      ),
    );
  }
}
