import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:spendee/providers/learning_provider.dart';
import 'package:spendee/screens/learning/level_detail_screen.dart';
import 'package:spendee/screens/learning/achievements_screen.dart';

class LearningScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final levels = Provider.of<LearningProvider>(context).levels;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Aprendizaje'),
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.emoji_events),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => AchievementsScreen()),
          );
        },
      ),
      body: ListView.builder(
        itemCount: levels.length,
        itemBuilder: (ctx, i) => ListTile(
          title: Text(levels[i].title),
          trailing: Icon(
            levels[i].completed ? Icons.check_circle : Icons.radio_button_unchecked,
            color: levels[i].completed ? Colors.green : Colors.grey,
          ),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => LevelDetailScreen(levelId: levels[i].id),
              ),
            );
          },
        ),
      ),
    );
  }
}
