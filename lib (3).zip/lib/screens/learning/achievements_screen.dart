import 'package:flutter/material.dart';

class AchievementsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Logros'),
      ),
      body: GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
        itemCount: 10,
        itemBuilder: (ctx, i) {
          bool unlocked = i % 2 == 0; // Simulación
          return Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: unlocked ? Colors.amber : Colors.grey,
            ),
            child: const Center(child: Icon(Icons.star, size: 40, color: Colors.white)),
          );
        },
      ),
    );
  }
}
