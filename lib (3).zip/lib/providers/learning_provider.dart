import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spendee/models/level.dart';

class LearningProvider with ChangeNotifier {
  List<Level> _levels = List.generate(
    10,
    (index) => Level(id: index, title: 'Nivel ${index + 1}', completed: false),
  );

  List<Level> get levels => _levels;

  Future<void> loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    for (var level in _levels) {
      level.completed = prefs.getBool('level_${level.id}_completed') ?? false;
    }
    notifyListeners();
  }

  Future<void> completeLevel(int id) async {
    final prefs = await SharedPreferences.getInstance();
    _levels[id].completed = true;
    await prefs.setBool('level_${id}_completed', true);
    notifyListeners();
  }
}
