import 'package:flutter/foundation.dart';
import 'package:hive_ce/hive.dart';

class LearningProvider with ChangeNotifier {
  static const String learningBoxName = 'learning_progress';

  late final Box _learningBox;

  int _currentLevel = 0; // Nivel alcanzado
  Set<int> _achievementsUnlocked = {}; // IDs de logros obtenidos
  int _totalQuestionsAnswered = 0; // NUEVO: total de preguntas respondidas

  int get currentLevel => _currentLevel;
  Set<int> get achievementsUnlocked => _achievementsUnlocked;
  int get totalQuestionsAnswered => _totalQuestionsAnswered;

  LearningProvider() {
    _initHive();
  }

  Future<void> _initHive() async {
    try {
      _learningBox = await Hive.openBox(learningBoxName);
      _loadProgress();
    } catch (e) {
      debugPrint('Error inicializando LearningProvider: \$e');
    }
  }

  void _loadProgress() {
    _currentLevel = _learningBox.get('currentLevel', defaultValue: 0);
    final achievements = _learningBox.get('achievementsUnlocked', defaultValue: []);
    _achievementsUnlocked = Set<int>.from(achievements);
    _totalQuestionsAnswered = _learningBox.get('totalQuestionsAnswered', defaultValue: 0);
    notifyListeners();
  }

  Future<void> completeLevel() async {
    _currentLevel++;
    await _learningBox.put('currentLevel', _currentLevel);
    notifyListeners();
  }

  Future<void> unlockAchievement(int achievementId) async {
    if (!_achievementsUnlocked.contains(achievementId)) {
      _achievementsUnlocked.add(achievementId);
      await _learningBox.put('achievementsUnlocked', _achievementsUnlocked.toList());
      notifyListeners();
    }
  }

  bool isAchievementUnlocked(int achievementId) {
    return _achievementsUnlocked.contains(achievementId);
  }

  Future<void> incrementQuestionsAnswered(int count) async {
    _totalQuestionsAnswered += count;
    await _learningBox.put('totalQuestionsAnswered', _totalQuestionsAnswered);
    notifyListeners();
  }

  void resetProgress() async {
    _currentLevel = 0;
    _achievementsUnlocked.clear();
    _totalQuestionsAnswered = 0;
    await _learningBox.clear();
    notifyListeners();
  }
}