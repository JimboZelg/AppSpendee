import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/learning_provider.dart';
import '../screens/level_detail_screen.dart';
import '../screens/achievements_screen.dart';

class LearningScreen extends StatelessWidget {
  const LearningScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final learningProvider = context.watch<LearningProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Camino de Aprendizaje'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: 10, // 10 niveles
        itemBuilder: (context, index) {
          final isUnlocked = index <= learningProvider.currentLevel;
          return Card(
            color: isUnlocked ? Colors.lightBlueAccent : Colors.grey[300],
            child: ListTile(
              leading: Icon(
                isUnlocked ? Icons.school : Icons.lock,
                color: isUnlocked ? Colors.white : Colors.grey,
              ),
              title: Text(
                'Nivel ${index + 1}',
                style: TextStyle(
                  color: isUnlocked ? Colors.white : Colors.black54,
                  fontWeight: FontWeight.bold,
                ),
              ),
              trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white),
              onTap: isUnlocked
                  ? () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => LevelDetailScreen(level: index + 1),
                        ),
                      );
                    }
                  : null,
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.amber,
        child: const Icon(Icons.emoji_events),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AchievementsScreen(),
            ),
          );
        },
      ),
    );
  }
}