import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/learning_provider.dart';

class AchievementsScreen extends StatelessWidget {
  const AchievementsScreen({super.key});

  static final List<Map<String, dynamic>> achievementsList = [
    {"id": 1, "name": "Completaste Nivel 1"},
    {"id": 2, "name": "Completaste Nivel 3"},
    {"id": 3, "name": "Completaste Nivel 5"},
    {"id": 4, "name": "Completaste Nivel 7"},
    {"id": 5, "name": "Completaste Nivel 10"},
    {"id": 6, "name": "Respondido 30 preguntas"},
    {"id": 7, "name": "100% respuestas correctas en un nivel"},
    {"id": 8, "name": "Terminaste todo el aprendizaje"},
    {"id": 9, "name": "Completaste 5 logros"},
    {"id": 10, "name": "Maestro del ahorro"},
  ];

  @override
  Widget build(BuildContext context) {
    final learningProvider = context.watch<LearningProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mis Logros'),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 1,
        ),
        itemCount: achievementsList.length,
        itemBuilder: (context, index) {
          final achievement = achievementsList[index];
          final unlocked = learningProvider.isAchievementUnlocked(achievement['id']);

          return Container(
            decoration: BoxDecoration(
              color: unlocked ? Colors.amber : Colors.grey[300],
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.emoji_events,
                  color: unlocked ? Colors.white : Colors.grey,
                  size: 48,
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Text(
                    achievement['name'],
                    style: TextStyle(
                      color: unlocked ? Colors.white : Colors.black45,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}