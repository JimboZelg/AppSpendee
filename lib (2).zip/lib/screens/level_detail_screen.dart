import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/learning_provider.dart';

class LevelDetailScreen extends StatefulWidget {
  final int level;

  const LevelDetailScreen({super.key, required this.level});

  @override
  State<LevelDetailScreen> createState() => _LevelDetailScreenState();
}

class _LevelDetailScreenState extends State<LevelDetailScreen> {
  bool _quizStarted = false;
  int _currentQuestion = 0;
  int _correctAnswers = 0;

  final List<String> _exampleQuestions = [
    "¿Qué es un presupuesto?",
    "¿Por qué es importante ahorrar?",
    "¿Qué significa una tasa de interés?",
    "¿Qué es un gasto fijo?",
    "¿Qué es una inversión?",
  ];

  void _answerQuestion(bool correct) {
    if (correct) _correctAnswers++;

    if (_currentQuestion < _exampleQuestions.length - 1) {
      setState(() {
        _currentQuestion++;
      });
    } else {
      _finishLevel();
    }
  }

  void _finishLevel() async {
    final learningProvider = context.read<LearningProvider>();

    if (widget.level == learningProvider.currentLevel) {
      await learningProvider.completeLevel();

      // Desbloquear logros automáticos según nivel
      switch (widget.level) {
        case 1:
          await learningProvider.unlockAchievement(1);
          break;
        case 3:
          await learningProvider.unlockAchievement(2);
          break;
        case 5:
          await learningProvider.unlockAchievement(3);
          break;
        case 7:
          await learningProvider.unlockAchievement(4);
          break;
        case 10:
          await learningProvider.unlockAchievement(5);
          await learningProvider.unlockAchievement(8); // Terminó todo
          break;
      }
    }

    // Incrementar total de preguntas respondidas
    await learningProvider.incrementQuestionsAnswered(_exampleQuestions.length);

    // Verificar logro de 30 preguntas respondidas
    if (learningProvider.totalQuestionsAnswered >= 30) {
      await learningProvider.unlockAchievement(6);
    }

    // Verificar logro de 100% respuestas correctas
    if (_correctAnswers == _exampleQuestions.length) {
      await learningProvider.unlockAchievement(7);
    }

    // Verificar logro de haber desbloqueado 5 logros
    if (learningProvider.achievementsUnlocked.length >= 5) {
      await learningProvider.unlockAchievement(9);
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Nivel completado!"),
        content: Text("Respondiste correctamente \$_correctAnswers de ${_exampleQuestions.length} preguntas."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text("Volver"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Nivel ${widget.level}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: _quizStarted ? _buildQuiz() : _buildLearningContent(),
      ),
    );
  }

  Widget _buildLearningContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Enseñanza del Nivel ${widget.level}',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        const Text(
          'Aquí iría una explicación o enseñanza interactiva del nivel...\n(Por ahora es un ejemplo)',
          style: TextStyle(fontSize: 16),
        ),
        const Spacer(),
        Center(
          child: ElevatedButton(
            onPressed: () {
              setState(() {
                _quizStarted = true;
              });
            },
            child: const Text('Iniciar Preguntas'),
          ),
        ),
      ],
    );
  }

  Widget _buildQuiz() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Pregunta ${_currentQuestion + 1}/${_exampleQuestions.length}',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        Text(
          _exampleQuestions[_currentQuestion],
          style: const TextStyle(fontSize: 16),
        ),
        const SizedBox(height: 32),
        ElevatedButton(
          onPressed: () => _answerQuestion(true),
          child: const Text('Responder Correcto'),
        ),
        ElevatedButton(
          onPressed: () => _answerQuestion(false),
          child: const Text('Responder Incorrecto'),
        ),
      ],
    );
  }
}