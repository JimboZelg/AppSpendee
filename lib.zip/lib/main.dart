import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'screens/home_screen.dart';
import 'providers/wallet_provider.dart';
import 'models/transaction_adapter.dart';
import 'models/goal_adapter.dart';

void main() async {
  // Ensure Flutter is initialized
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Hive with Flutter
  await Hive.initFlutter();
  
  // Register our custom adapters
  if (!Hive.isAdapterRegistered(0)) {
    Hive.registerAdapter(TransactionAdapter());
  }
  if (!Hive.isAdapterRegistered(1)) {
    Hive.registerAdapter(GoalAdapter());
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => WalletProvider(),
      child: MaterialApp(
        title: 'Spendee',
        theme: ThemeData(
          primaryColor: const Color(0xFF87CEEB),
          scaffoldBackgroundColor: const Color(0xFF87CEEB),
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF87CEEB),
            primary: const Color(0xFF87CEEB),
            secondary: const Color(0xFFFFEB3B),
            error: const Color(0xFFFF0000),
            tertiary: const Color(0xFF4CAF50),
          ),
          useMaterial3: true,
        ),
        home: const HomeScreen(),
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
