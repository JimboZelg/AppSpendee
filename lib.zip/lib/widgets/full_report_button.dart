
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import '../providers/wallet_provider.dart';
import '../models/transaction_type.dart';

class FullReportButton extends StatelessWidget {
  const FullReportButton({super.key});

  Future<Uint8List> _generatePdf(BuildContext context) async {
    final walletProvider = Provider.of<WalletProvider>(context, listen: false);
    final transactions = walletProvider.transactions;
    final completedGoals = walletProvider.completedGoals;

    final totalIncome = walletProvider.totalIncome;
    final totalExpenses = walletProvider.totalExpenses;
    final totalSavings = totalIncome - totalExpenses;

    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (context) => [
          pw.Header(level: 0, child: pw.Text("Reporte Financiero Spendee", style: pw.TextStyle(fontSize: 22))),
          pw.Text("Resumen General", style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
          pw.Bullet(text: "Ingresos: \$${totalIncome.toStringAsFixed(2)}"),
          pw.Bullet(text: "Gastos: \$${totalExpenses.toStringAsFixed(2)}"),
          pw.Bullet(text: "Ahorro: \$${totalSavings.toStringAsFixed(2)}"),
          pw.SizedBox(height: 16),
          pw.Text("Tabla de Transacciones", style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.Table.fromTextArray(
            headers: ['Fecha', 'Categoría', 'Monto', 'Tipo', 'Descripción'],
            data: transactions.map((tx) => [
              "\${tx.date.day}/${tx.date.month}/${tx.date.year}",
              tx.category,
              "\$${tx.amount.toStringAsFixed(2)}",
              tx.type == TransactionType.income ? 'Ingreso' : 'Gasto',
              tx.description
            ]).toList(),
            cellStyle: pw.TextStyle(fontSize: 10),
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 16),
          pw.Text("Metas Cumplidas", style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.Table.fromTextArray(
            headers: ['Nombre', 'Total Ahorrado', 'Frecuencia'],
            data: completedGoals.map((goal) => [
              goal.name,
              "\$${goal.currentAmount.toStringAsFixed(2)}",
              goal.frequency
            ]).toList(),
            cellStyle: pw.TextStyle(fontSize: 10),
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
          ),
        ],
      ),
    );

    return pdf.save();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ElevatedButton.icon(
        icon: const Icon(Icons.picture_as_pdf),
        label: const Text("Reporte Completo en PDF"),
        style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo),
        onPressed: () async {
          final pdfBytes = await _generatePdf(context);
          await Printing.layoutPdf(onLayout: (format) async => pdfBytes);
        },
      ),
    );
  }
}
